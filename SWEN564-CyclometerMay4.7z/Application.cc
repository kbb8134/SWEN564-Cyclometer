/*Application.cc
 *
 * The main file for running the Cyclometer simulation
 *
 * Author: Kristopher Brown & Madeleine Daigneau
 *
 */

int main(int argc, char** argv){


	return 0;
}
