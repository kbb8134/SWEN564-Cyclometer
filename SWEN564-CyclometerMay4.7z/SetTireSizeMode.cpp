/*
 * SetTireSizeMode.cpp
 *
 *  Created on: May 4, 2016
 *      Author: Madeleine Daigneau & Kristopher Brown
 */

#include "SetTireSizeMode.h"

void SetTireSizeMode::onEnter(StateMachine& statemachine){

}

void SetTireSizeMode::accept(StateMachine& statemachine){

}

void SetTireSizeMode::onExit(StateMachine& statemachine){

}
