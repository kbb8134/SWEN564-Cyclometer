/*
 * Cyclometer.cpp
 *
 *  Created on: May 4, 2016
 *      Author: Madeleine Daigneau & Kristopher Brown
 */

#include "Cyclometer.h"

Cyclometer::Cyclometer() {
	// TODO Auto-generated constructor stub

}

Cyclometer::~Cyclometer() {
	// TODO Auto-generated destructor stub
}

void Cyclometer::calculate(){

}

void Cyclometer::setCalculations(bool in){
	this -> doCalculate = in;
}
