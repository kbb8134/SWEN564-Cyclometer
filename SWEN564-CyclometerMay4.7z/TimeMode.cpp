/*
 * TimeMode.cpp
 *
 *  Created on: May 4, 2016
 *      Author: Madeleine Daigneau & Kristopher Brown
 */

#include "TimeMode.h"

void TimeMode::onEnter(StateMachine& statemachine){

}

void TimeMode::accept(StateMachine& statemachine){

}

void TimeMode::onExit(StateMachine& statemachine){

}
