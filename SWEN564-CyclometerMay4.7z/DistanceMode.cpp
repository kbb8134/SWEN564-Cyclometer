/*
 * DistanceMode.cpp
 *
 *  Created on: May 4, 2016
 *      Author: Madeleine Daigneau & Kristopher Brown
 */

#include "DistanceMode.h"

void DistanceMode::onEnter(StateMachine& statemachine){

}

void DistanceMode::accept(StateMachine& statemachine){

}

void DistanceMode::onExit(StateMachine& statemachine){

}
