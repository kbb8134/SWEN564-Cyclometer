/*
 * SetKmMiMode.cpp
 *
 *  Created on: May 4, 2016
 *      Author: Kristopher Brown & Madeleine Daigneau
 */

#include "SetKmMiMode.h"

void SetKmMiMode::onEnter(StateMachine& statemachine){

}

void SetKmMiMode::accept(StateMachine& statemachine){

}

void SetKmMiMode::onExit(StateMachine& statemachine){

}

