/*
 * IOControl.cpp
 *
 *  Created on: May 4, 2016
 *      Author: Kristopher Brown & Madeleine Daigneau
 */

#include "IOControl.h"

IOControl::IOControl() {
	// TODO Auto-generated constructor stub

}

IOControl::~IOControl() {
	// TODO Auto-generated destructor stub
}

/*
 * Function to receive input from the QNX box
 */
void IOControl::receive(){

}
