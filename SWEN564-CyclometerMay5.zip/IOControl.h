/*
 * IOControl.h
 *
 *  Created on: May 4, 2016
 *      Author: Kristopher Brown & Madeleine Daigneau
 */

#ifndef IOCONTROL_H_
#define IOCONTROL_H_

class IOControl {
public:

	/*
	 * Add I/O Registers and message_queue l8r
	 */

	IOControl();
	~IOControl();

	void receive();

};

#endif /* IOCONTROL_H_ */
