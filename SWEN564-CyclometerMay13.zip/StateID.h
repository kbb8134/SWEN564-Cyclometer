/*
 * StateID.h
 *
 *  Created on: May 13, 2016
 *      Author: kbb8134
 */

#ifndef STATEID_H_
#define STATEID_H_


enum StateID {

	SETTIRESIZEMODE = 1,
	SETKMMIMODE = 2,
	TIMEMODE = 3,
	DISTANCEMODE = 4,
	SPEEDMODE = 5

};


#endif /* STATEID_H_ */
